import numpy as np
arr = np.load('test_extract/Assault004_x264_i3d.npy')
print(arr.shape)